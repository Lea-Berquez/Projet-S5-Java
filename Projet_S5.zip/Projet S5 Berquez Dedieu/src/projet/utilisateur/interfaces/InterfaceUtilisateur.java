package projet.utilisateur.interfaces;

public class InterfaceUtilisateur {

	public static void main(String[] args) {
		InterfaceUtilisateurConnexion interfaceUtilisateur = new InterfaceUtilisateurConnexion();
		interfaceUtilisateur.setVisible(true);
//		InterfaceUtilisateurCreationTicket interfaceUtilisateurBis = new InterfaceUtilisateurCreationTicket();
//		interfaceUtilisateurBis.setVisible(true);
	}
}
