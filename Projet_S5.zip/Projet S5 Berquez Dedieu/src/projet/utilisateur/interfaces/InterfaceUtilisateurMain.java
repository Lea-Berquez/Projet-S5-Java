package projet.utilisateur.interfaces;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Enumeration;
import java.util.Set;

import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.ScrollPaneConstants;
import javax.swing.Timer;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.TreeCellRenderer;

import projet.utilisateur.Client;
import projet.utilisateur.Groupe;
import projet.utilisateur.Ticket;

public class InterfaceUtilisateurMain extends JFrame {

	private static final long serialVersionUID = 1L;

	Client client;
	JTable tableConversation = new JTable();
	JScrollPane conversation = new JScrollPane(tableConversation, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	DefaultMutableTreeNode conv = new DefaultMutableTreeNode("Groupes");
	JTree conversations = new JTree(conv);
	JScrollPane treePane = new JScrollPane(conversations, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
			ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
	JTextField message;
	Boolean close = false;

	Timer timer = new Timer(1800, new ActionListener() {

		@Override
		public void actionPerformed(ActionEvent e) {
			client.demandeRafraichissement(client.getUtilisateur().getIdentifiant(), client.getUtilisateur().getMdp());
			// timer.stop();
		}
	});

	Ticket ticketSelectionne;

	private GestionnaireFenetreUtilisateur gf;

	@SuppressWarnings("unused")
	public InterfaceUtilisateurMain(Client c, Ticket t) {
		super();
		client = c;

		gf = new GestionnaireFenetreUtilisateur(client, timer);
		boolean test = client.demandeRafraichissement(client.getUtilisateur().getIdentifiant(),
				client.getUtilisateur().getMdp());

		if (t != null) {
			client.lectureTicket(t.getIdentifiant(), client.getUtilisateur().getIdentifiant());

			ticketSelectionne = t;
			for (Ticket ti : client.getUtilisateur().getTickets()) {
				if (ti.getIdentifiant().equals(ticketSelectionne.getIdentifiant())) {
					ticketSelectionne = ti;
				}
			}
			if (ticketSelectionne.getMessages() != null && ticketSelectionne.getMessages().size() > 0) {
				TableauMessage tMessage = new TableauMessage(ticketSelectionne.getMessages());
				tableConversation = new JTable(tMessage);

				TableColumnModel modeleColonne = tableConversation.getColumnModel();

				modeleColonne.getColumn(0).setCellRenderer(new RenduTableau());
				modeleColonne.getColumn(1).setCellRenderer(new RenduTableau());
				modeleColonne.getColumn(2).setCellRenderer(new RenduTableau());

				tableConversation.setColumnModel(modeleColonne);

				int col = 0, larg = 0, largTotal = 0, row = 0, tableX = 0, width = 0;
				JTableHeader header = tableConversation.getTableHeader();
				Enumeration<TableColumn> columns = tableConversation.getColumnModel().getColumns();

				tableConversation.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);

				while (columns.hasMoreElements()) {
					TableColumn column = (TableColumn) columns.nextElement();
					col = header.getColumnModel().getColumnIndex(column.getIdentifier());
					width = (int) tableConversation.getTableHeader().getDefaultRenderer()
							.getTableCellRendererComponent(tableConversation, column.getIdentifier(), false, false, -1,
									col)
							.getPreferredSize().getWidth();
					for (row = 0; row < tableConversation.getRowCount(); row++) {
						int preferedWidth = (int) tableConversation.getCellRenderer(row, col)
								.getTableCellRendererComponent(tableConversation,
										tableConversation.getValueAt(row, col), false, false, row, col)
								.getPreferredSize().getWidth();
						width = Math.max(width, preferedWidth);
					}
					header.setResizingColumn(column);
					larg = width + tableConversation.getIntercellSpacing().width;
					larg = larg + 20;
					largTotal += larg;
					column.setWidth(larg);
				}

				tableConversation.setVisible(true);
				tableConversation.setAutoscrolls(true);

				Color couleur = new Color(189, 217, 230);
				conversations.setBackground(couleur);

				TreeCellRenderer cellRenderer = conversations.getCellRenderer();
				if (cellRenderer instanceof DefaultTreeCellRenderer) {
					DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) cellRenderer;
					renderer.setBackgroundNonSelectionColor(couleur);
					renderer.setBackgroundSelectionColor(Color.white);
					renderer.setTextSelectionColor(Color.black);
					renderer.setTextNonSelectionColor(Color.black);
				}

				conversation.getViewport().add(tableConversation);

				// client.lectureTicket(ticketSelectionne.getIdentifiant(),
				// client.getUtilisateur().getIdentifiant());
				client.demandeRafraichissement(client.getUtilisateur().getIdentifiant(),
						client.getUtilisateur().getMdp());
				setVisible(true);
				build();
			} else {
				ticketSelectionne = t;

				setVisible(true);
				build();
			}
		} else {
			System.out.println(">>>>>>>>>>>> t == null");

			ticketSelectionne = new Ticket("Selectionner ticket", null, null, null, null);
			setVisible(true);
			build();
		}
	}

	private void build() {
//		System.out.println("Interface utilisateur ticket : ");
//		for (Ticket ticket : client.getUtilisateur().getTickets()) {
//			System.out.println("Ticket : " + ticket.getTitre());
//		}

		addWindowListener(gf);
		setTitle("Interface Utilisateur - " + client.getUtilisateur().getIdentite());
		setVisible(true);
		setSize(900, 900);
		setLocationRelativeTo(null);
		setResizable(true);
		setContentPane(buildContentPane());
		pack();

	}

	private JPanel buildContentPane() {
		JPanel root = new JPanel();
		root.setBackground(Color.white);
		this.add(root);

		GroupLayout layout = new GroupLayout(root);
		root.setLayout(layout);

		JButton ajouterTicket = new JButton("+Ticket");

		ajouterTicket.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				InterfaceUtilisateurCreationTicket iterT = new InterfaceUtilisateurCreationTicket(client);
				iterT.setVisible(true);
				// timer.stop();
				dispose();
			}
		});

		message = new JTextField();

		JButton envoyerMessage = new JButton("Envoyer");

		envoyerMessage.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				String message_string = message.getText();
				boolean reussi = false;
				if (message_string != null && !message_string.equals("") && ticketSelectionne != null) {
					reussi = client.creationMessage(client.getUtilisateur().getIdentifiant(),
							ticketSelectionne.getIdentifiant(), client.getUtilisateur().getIdentite(), message_string);
				}
				if (reussi) {
					message.setText("");
					client.demandeRafraichissement(client.getUtilisateur().getIdentifiant(),
							client.getUtilisateur().getMdp());
					new InterfaceUtilisateurMain(client, ticketSelectionne);
					// timer.stop();
					// dispose();
					setVisible(false);
				} else {
					JOptionPane.showMessageDialog(root, "Erreur cr�ation message", "Erreur", JOptionPane.ERROR_MESSAGE,
							null);

				}
			}
		});

		// System.out.println(client.toString());
		Set<Groupe> setGroupes = client.getUtilisateur().getGroupes();
		Set<Ticket> setTickets = client.getUtilisateur().getTickets();

		for (Groupe g : setGroupes) {
			DefaultMutableTreeNode groupe = new DefaultMutableTreeNode(g.getNom());

			for (Ticket t : setTickets) {
				// System.out.println(t.getTitre());
				DefaultMutableTreeNode ticket = new DefaultMutableTreeNode(t);

				if (t.getGroupeEmetteur().getNom().equals(g.getNom())
						|| t.getGroupeRecepteur().getNom().equals(g.getNom())) {
					groupe.add(ticket);
				}
			}

			conv.add(groupe);
		}

		conversations = new JTree(conv);

		conversations.setShowsRootHandles(true);

		for (int i = 0; i < conversations.getRowCount(); i++) {
			conversations.expandRow(i);
		}

		treePane = new JScrollPane(conversations);

		JLabel titreTicket = new JLabel(ticketSelectionne.getTitre(), JLabel.CENTER);

		conversations.addTreeSelectionListener(new TreeSelectionListener() {

			@SuppressWarnings("unused")
			@Override
			public void valueChanged(TreeSelectionEvent e) {
				DefaultMutableTreeNode noeud = (DefaultMutableTreeNode) conversations.getLastSelectedPathComponent();

				if (noeud != null) {
					if (noeud.getUserObject() instanceof Ticket) {
						// System.out.println("Selection ticket");
						ticketSelectionne = (Ticket) noeud.getUserObject();
						titreTicket.setText(ticketSelectionne.getTitre());

						client.lectureTicket(ticketSelectionne.getIdentifiant(),
								client.getUtilisateur().getIdentifiant());
						new InterfaceUtilisateurMain(client, ticketSelectionne);
						// dispose();
						setVisible(false);
					}
				}
			}
		});

		JButton rafraichir = new JButton("Rafraichir");

		rafraichir.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				client.demandeRafraichissement(client.getUtilisateur().getIdentifiant(),
						client.getUtilisateur().getMdp());

				for (Ticket t : client.getUtilisateur().getTickets()) {
					if (t.getIdentifiant().equals(ticketSelectionne.getIdentifiant())) {
						ticketSelectionne = t;
					}
				}

				new InterfaceUtilisateurMain(client, ticketSelectionne);
				setVisible(false);

			}
		});

		Color couleur = new Color(189, 217, 230);
		conversations.setBackground(couleur);

		TreeCellRenderer cellRenderer = conversations.getCellRenderer();
		if (cellRenderer instanceof DefaultTreeCellRenderer) {
			DefaultTreeCellRenderer renderer = (DefaultTreeCellRenderer) cellRenderer;
			renderer.setBackgroundNonSelectionColor(couleur);
			renderer.setBackgroundSelectionColor(Color.white);
			renderer.setTextSelectionColor(Color.black);
			renderer.setTextNonSelectionColor(Color.black);
		}

		JPanel panel1 = new JPanel();
		JPanel panel2 = new JPanel();
		JPanel panel3 = new JPanel();
		JPanel panel4 = new JPanel();

		Font font = new Font("Gras", Font.BOLD, 19);
		titreTicket.setFont(font);

		BorderLayout layout1 = new BorderLayout();
		BorderLayout layout2 = new BorderLayout();
		BorderLayout layout3 = new BorderLayout();
		BorderLayout layout4 = new BorderLayout();

		panel1.setLayout(layout1);
		panel2.setLayout(layout2);
		panel3.setLayout(layout3);
		panel4.setLayout(layout4);

		panel4.add("North", rafraichir);
		panel4.add("Center", ajouterTicket);

		panel1.add("North", panel4);
		panel1.add("Center", treePane);

		panel2.add("Center", message);
		panel2.add("South", envoyerMessage);

		panel3.add("North", titreTicket);
		panel3.add("Center", conversation);
		panel3.add("South", panel2);

		GroupLayout.SequentialGroup hGroup = layout.createSequentialGroup();

		hGroup.addGroup(layout.createParallelGroup().addComponent(panel1));
		hGroup.addGroup(layout.createParallelGroup().addComponent(panel3));

		layout.setHorizontalGroup(hGroup);

		GroupLayout.SequentialGroup vGroup = layout.createSequentialGroup();

		vGroup.addGroup(layout.createParallelGroup(Alignment.BASELINE).addComponent(panel1).addComponent(panel3));

		layout.setVerticalGroup(vGroup);

		return root;
	}
}
