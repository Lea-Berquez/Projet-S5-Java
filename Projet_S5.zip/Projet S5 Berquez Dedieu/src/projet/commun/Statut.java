package projet.commun;

public enum Statut {
	INCONNU,ETUDIANT,ENSEIGNANT,ADMINISTRATIF,ENTRETIEN; 
}
